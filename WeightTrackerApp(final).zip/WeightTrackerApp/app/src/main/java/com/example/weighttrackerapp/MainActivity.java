package com.example.weighttrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText userEt, passEt;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userEt = findViewById(R.id.usernameEditText);
        passEt = findViewById(R.id.passwordEditText);
        Button login = findViewById(R.id.loginButton);
        Button register = findViewById(R.id.registerButton);
        db = new DBHelper(this);

        login.setOnClickListener(v -> {
            String u = userEt.getText().toString().trim();
            String p = passEt.getText().toString().trim();
            if (db.checkUser(u, p)) {
                startActivity(new Intent(this, DashboardActivity.class).putExtra("username", u));
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        register.setOnClickListener(v -> {
            String u = userEt.getText().toString().trim();
            String p = passEt.getText().toString().trim();
            if (db.insertUser(u, p)) {
                Toast.makeText(this, "User registered", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, DashboardActivity.class).putExtra("username", u));
            } else {
                Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
