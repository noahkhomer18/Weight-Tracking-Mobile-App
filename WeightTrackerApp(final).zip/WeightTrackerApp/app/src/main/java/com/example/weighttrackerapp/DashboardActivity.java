package com.example.weighttrackerapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {
    DBHelper db;
    String username;
    ArrayList<String> data;
    ArrayAdapter<String> adapter;
    GridView grid;
    TextView goalText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        db = new DBHelper(this);
        username = getIntent().getStringExtra("username");

        grid = findViewById(R.id.gridView);
        goalText = findViewById(R.id.goalText);
        FloatingActionButton fab = findViewById(R.id.fabAdd);

        fab.setOnClickListener(v -> {
            Intent i = new Intent(this, AddEntryActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        grid.setOnItemClickListener((parent, view, pos, id) -> {
            String item = data.get(pos);
            int entryId = Integer.parseInt(item.split(" ")[0]);
            new AlertDialog.Builder(this)
                    .setTitle("Delete or Update?")
                    .setMessage(item)
                    .setPositiveButton("Delete", (d, w) -> {
                        db.deleteWeight(entryId);
                        Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                        loadData();
                    })
                    .setNegativeButton("Update", (d, w) -> {
                        Intent i = new Intent(this, AddEntryActivity.class);
                        i.putExtra("username", username);
                        i.putExtra("updateId", entryId);
                        startActivity(i);
                    })
                    .show();
        });

        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        data = new ArrayList<>();
        Cursor c = db.getWeights(username);
        while (c.moveToNext()) {
            int id = c.getInt(0);
            float w = c.getFloat(2);
            String d = c.getString(3);
            data.add(id + "  " + w + " lbs  (" + d + ")");
        }
        c.close();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data);
        grid.setAdapter(adapter);

        float goal = db.getGoalWeight(username);
        goalText.setText("Goal: " + goal + " lbs");
    }
}
