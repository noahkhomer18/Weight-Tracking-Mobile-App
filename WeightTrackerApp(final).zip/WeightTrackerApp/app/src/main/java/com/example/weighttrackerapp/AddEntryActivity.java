package com.example.weighttrackerapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class AddEntryActivity extends AppCompatActivity {
    private static final int SMS_CODE = 101;

    DBHelper db;
    String username;
    int updateId = -1;

    EditText weightEt, dateEt, phoneEt, goalEt;
    float goalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_entry);

        weightEt = findViewById(R.id.weightInput);
        dateEt = findViewById(R.id.dateInput);
        phoneEt = findViewById(R.id.phoneInput);
        goalEt = findViewById(R.id.goalInput);
        Button saveBtn = findViewById(R.id.saveButton);

        db = new DBHelper(this);
        username = getIntent().getStringExtra("username");
        updateId = getIntent().getIntExtra("updateId", -1);
        goalWeight = db.getGoalWeight(username);

        saveBtn.setOnClickListener(v -> saveEntry());
    }

    private void saveEntry() {
        float weight = Float.parseFloat(weightEt.getText().toString());
        String date = dateEt.getText().toString();
        String phone = phoneEt.getText().toString();
        String goalStr = goalEt.getText().toString().trim();

        if (!goalStr.isEmpty()) {
            goalWeight = Float.parseFloat(goalStr);
            db.updateGoalWeight(username, goalWeight);
        }

        boolean ok = (updateId == -1)
                ? db.addWeight(username, weight, date)
                : db.updateWeight(updateId, weight, date);

        if (!ok) {
            Toast.makeText(this, "Error saving entry", Toast.LENGTH_SHORT).show();
            return;
        }

        if (weight <= goalWeight && !phone.isEmpty()) {
            askSmsPermissionAndSend(phone, "Goal weight " + weight + " lbs reached.");
        }

        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void askSmsPermissionAndSend(String phone, String msg) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_CODE);
        } else {
            sendSms(phone, msg);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == SMS_CODE && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            saveEntry();
        } else {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSms(String phone, String msg) {
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed", Toast.LENGTH_SHORT).show();
        }
    }
}
