package com.example.weighttrackerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DBNAME = "WeightTracker.db";

    public DBHelper(Context context) {
        super(context, DBNAME, null, 2); // Bump version to force schema update if needed
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(username TEXT PRIMARY KEY, password TEXT, goal REAL)");
        db.execSQL("CREATE TABLE weights(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, weight REAL, date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        onCreate(db);
    }

    public boolean insertUser(String username, String password) {
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        cv.put("goal", 160.0); // default goal
        return getWritableDatabase().insert("users", null, cv) != -1;
    }

    public boolean checkUser(String username, String password) {
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String[]{username, password});
        boolean ok = c.getCount() > 0;
        c.close();
        return ok;
    }

    public boolean updateGoalWeight(String username, float goal) {
        ContentValues cv = new ContentValues();
        cv.put("goal", goal);
        return getWritableDatabase().update("users", cv, "username=?", new String[]{username}) > 0;
    }

    public float getGoalWeight(String username) {
        Cursor c = getReadableDatabase().rawQuery("SELECT goal FROM users WHERE username=?", new String[]{username});
        float result = 160f;
        if (c.moveToFirst()) result = c.getFloat(0);
        c.close();
        return result;
    }

    public boolean addWeight(String username, float weight, String date) {
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("weight", weight);
        cv.put("date", date);
        return getWritableDatabase().insert("weights", null, cv) != -1;
    }

    public Cursor getWeights(String username) {
        return getReadableDatabase().rawQuery("SELECT * FROM weights WHERE username=?", new String[]{username});
    }

    public boolean updateWeight(int id, float weight, String date) {
        ContentValues cv = new ContentValues();
        cv.put("weight", weight);
        cv.put("date", date);
        return getWritableDatabase().update("weights", cv, "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean deleteWeight(int id) {
        return getWritableDatabase().delete("weights", "id=?", new String[]{String.valueOf(id)}) > 0;
    }
}
